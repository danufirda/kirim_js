## 6.0.1 (2023-05-18)


### Bug Fixes

* In memory store: normalize user when asserting message list to update messages ([#49](https://github.com/WhiskeySockets/Baileys/issues/49)) ([7b4abcd](https://github.com/WhiskeySockets/Baileys/commit/7b4abcdb231434c08c14dbb5879cd1fd4939fc41))



